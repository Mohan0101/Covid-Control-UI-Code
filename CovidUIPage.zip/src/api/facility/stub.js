const facilityList = [
  {
    name: 'asdad asd',
    type: 'CCC',
    status: 'COVID only',
    jurisdiction: 'PMC',
    area: 'asdsa',
    link: 'Link Full'
  },
  {
    name: 'asdad asd',
    type: 'CCC',
    status: 'COVID only',
    jurisdiction: 'PMC',
    area: 'asdsa',
    link: 'No Link'
  },
  {
    name: 'asdad asd',
    type: 'CCC',
    status: 'COVID only',
    jurisdiction: 'PMC',
    area: 'asdsa',
    link: 'No Link'
  },
  {
    name: 'asdad asd',
    type: 'CCC',
    status: 'COVID only',
    jurisdiction: 'PMC',
    area: 'asdsa',
    link: 'No Link'
  }
];

export default {
  facilityList: {
    body: {
      data: facilityList
    }
  }
};
