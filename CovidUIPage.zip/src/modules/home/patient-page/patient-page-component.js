import React from 'react';
import TotalCovidPatientChart from './total-covid-patient-chart/total-covid-patient-chart'
import SeverityComponent from './severity/severity';

import './patient-page-component.scss';
const PatientflowComponent = (props)=>{
    const ageChartXaxisData = ['0 - 17','18 - 44','45 - 64','65 - 75', '75+'];
    const genderChartXaxisData = ['Male','Female','Others'];
   const ageDataList  = [{
        name: 'Mid',
        data: [49, 71, 106, 129, 144],
        color:'#FFC107'
  
    }, {
        name: 'Moderate',
        data: [83, 78, 98, 93, 106],
        color:'#FF9800'
  
    }, {
        name: 'Severe',
        data: [48, 38, 39.3, 41, 47],
        color:'#F44336'
  
    }];

    const GenderDataList  = [{
        name: 'Mid',
        data: [49, 71, 106],
        color:'#FFC107'
  
    }, {
        name: 'Moderate',
        data: [83, 78, 98],
        color:'#FF9800'
  
    }, {
        name: 'Severe',
        data: [48, 38, 39],
        color:'#F44336'
  
    }];

   return (
       <div className='patientFlowpage'>
           <div>
           <button className='backButton' onClick={props.BackToFacility}> {'<< '}back</button>
           </div>        
        
        <TotalCovidPatientChart></TotalCovidPatientChart>
        <SeverityComponent title = 'Age & Severity' categories = {ageChartXaxisData} data = {ageDataList}></SeverityComponent>
        <SeverityComponent title = 'Gender & Severity' categories = {genderChartXaxisData}  data = {GenderDataList}>></SeverityComponent>
       </div>
   )
}

export default PatientflowComponent;
