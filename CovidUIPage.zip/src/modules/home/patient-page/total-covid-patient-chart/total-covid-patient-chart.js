import React from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official';

const TotalCovidPatientChart =()=>{

    const options = {
 
        chart: {
            type: 'column'
        },
        title: {
            text: 'Total COVID Pateints'
        },
        xAxis: {
            categories: ['March', 'April', 'May', 'June', 'July']
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Number of Patients'
            }
        },
        tooltip: {
            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
            shared: true
        },
        plotOptions: {
            column: {
                stacking: 'percent'
            }
        },
        series: [{
            name: 'Active COVID',
            data: [5, 3, 4, 7, 2],
            color:'blue'
        }, {
            name: 'Deceased',
            data: [2, 2, 3, 2, 1],
            color:'black'
        }, {
            name: ' Recovered',
            data: [3, 4, 4, 2, 5],
            color:'green'
        }]
        }

  return (
     <div>
           <div className='facilityTile shadow'>
              <HighchartsReact
                highcharts={Highcharts}
                options={options}

              />
            </div>
     </div>
  ) 
}
export default TotalCovidPatientChart;