import React, { useState, useEffect } from 'react';
import './beds.scss';
import BedTileComponent from './bedTile'
import ProgressBar from '../progress-component/progress-component'
const BedsPage = (props) => {
    const totalBeds = 20000;
    const usedBeds = 9999;
    const usedBedsToday = 3000;




    return (
        <>

            <div className='BedContainer'>
                <button className='backButton' onClick={props.BackToFacility}> {'<< '}back</button>
                <div className='facilityTile shadow' >
                    <div className='progressBarParent'>
                        <div className='progressCounts'>
                            <div className='LeftCount textColor'> 2200 </div>
                            <div className='RightCount textColor'> 20000 </div>
                        </div>

                        <ProgressBar percent1={usedBeds} percent2={usedBeds + usedBedsToday} percentOf={totalBeds} bgColor={'#3c2f2f'}></ProgressBar>
                        <div className='progressCounts'>
                            <div className='LeftCount textColor'> Total Covid Beds </div>
                            <div className='RightCount textColor'> Maximum Beds Capacity </div>

                        </div>

                    </div>
                </div>
                <BedTileComponent
                    Lable={'Total Severe COVID Beds'}
                    availableCount={1750}
                    availableTodayCnt={200}
                    TotalCnt={'110 (+25)'}
                    bgColor={'#d41f1f'}

                >

                </BedTileComponent>
                <BedTileComponent
                    Lable={'Total Moderate COVID Beds'}
                    availableCount={1750}
                    availableTodayCnt={200}
                    TotalCnt={'110 (+25)'}
                    bgColor={'#FF9800'}

                >

                </BedTileComponent>
                <BedTileComponent
                    Lable={'Total Mild COVID Beds'}
                    availableCount={1750}
                    availableTodayCnt={200}
                    TotalCnt={'110 (+25)'}
                    bgColor={'#FF5722'}

                >

                </BedTileComponent>
                
               
             

               

            </div>
        </>
    );
};

export default BedsPage;
