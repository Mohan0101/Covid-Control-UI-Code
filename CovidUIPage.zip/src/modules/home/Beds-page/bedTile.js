import React from 'react';
import ProgressBar from '../progress-component/progress-component';
import bedImg from '../../../assets/img/bed.png';
const BedTileComponent = (props)=>{
    const ImgStyle = { height: '40px',
    width: '50px',
    float: 'right',
    marginBottom: '15px'};

 return (
     <>
     <div className="facilityContainer">
              <div className='facilityTile shadow'>
                <div className="totalbeds">
      <div className='tileLabel'>{props.Lable}</div>
                  <div className='Count'>
                      {props.availableCount} <sub className='subTexttextColor'>Available</sub>
                      <div style={ImgStyle}>
                          <img style ={{height:'100%',width:'100%'}} src = {bedImg} alt='bedIcon'></img>
                      </div>
                      </div>
                </div>
                
                <div className='progressBarParent'>
                  <div className='progressCounts'>
                    <div className='LeftCount textColor'>{props.TotalCnt}</div>
                    <div className='RightCount textColor'>  {props.availableTodayCnt} </div>

                  </div>
                  <ProgressBar percent1 ={110} percent2 ={125} percentOf = {200} bgColor = {props.bgColor}></ProgressBar>
                  <div className='tileLabel'>Confirmed</div>
                  <ProgressBar percent1 ={110} percent2 ={125} percentOf = {200} bgColor = {props.bgColor}></ProgressBar>
                  <div className='tileLabel'>Suspected</div>
                  <ProgressBar percent1 ={110} percent2 ={125} percentOf = {200} bgColor = {props.bgColor}></ProgressBar>
                
                </div>
              </div>
            </div>
     </>
 );

}
export default BedTileComponent;