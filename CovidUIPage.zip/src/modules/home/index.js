import React, { useRef, useEffect, useState } from 'react';
import { Header, Content } from 'components/layout';
import { Spin } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import { render } from 'react-dom'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official';
import userService from 'services/user-service.js';
// import { Report } from 'react-powerbi';
import FacilityDashbord from './facility-page/facility-page';
import BedsPage from './Beds-page/beds';
import PatientflowComponent from './patient-page/patient-page-component'

import './home.scss';

const antIcon = (
  <LoadingOutlined style={{ fontSize: 52, fontWeight: 500 }} spin />
);
export default function Home() {
  const [loading, setloading] = useState(false);
  const [isDisplayBeds,setIsDisplayBeds] = useState(false);
  const [isDisplayPatients,setIsDisplayPatients] = useState(false);
  
const toggleBeds = ()=>{
  setIsDisplayPatients(false);
  setIsDisplayBeds(true);
};
const togglePatients = ()=>{
  setIsDisplayBeds(false);
  setIsDisplayPatients(true);
};

const BackToFacility = ()=>{
  setIsDisplayBeds(false);
  setIsDisplayPatients(false);
};
  useEffect(() => {

  }, []);

  return (
    <>
      <Header>Dashboard</Header>
      <Content
        style={{
          padding: 0
        }}
      > 

      {
        isDisplayBeds || isDisplayPatients? 
        <>
        {
            isDisplayBeds ? 
            <BedsPage BackToFacility = {BackToFacility}></BedsPage>
            :
            <PatientflowComponent 
            BackToFacility = {BackToFacility} ></PatientflowComponent>
        }
         
        </> 
       
        :
        <FacilityDashbord onBedClick = {toggleBeds} onPatientClick = {togglePatients}></FacilityDashbord>
      }
        
      </Content>
    </>
  );
}
