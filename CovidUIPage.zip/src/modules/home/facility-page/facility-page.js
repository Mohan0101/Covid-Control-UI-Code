import React from 'react';
import './facility-page.scss';
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official';
import ProgressBar from '../progress-component/progress-component'
import bedImg from '../../../assets/img/bed.png';


const FacilityDashbord = (props)=>{
    const ImgStyle = { height: '40px',
    width: '50px',
    float: 'right',
    marginBottom: '15px'};

    const options = {
 
        chart: {
            type: 'column'
        },
    
        title: {
            text: 'Beds Total and Occupied Timeline'
        },
    
        xAxis: {
            categories: ['March', 'Apr', 'May','June','July','Aug','Sept','Oct']
        },
    
        yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
                text: 'Number of Beds'
            }
        },
    
        // tooltip: {
        //     formatter: function () {
        //         return '<b>' + this.x + '</b><br/>' +
        //             this.series.name + ': ' + this.y + '<br/>' +
        //             'Total: ' + this.point.stackTotal;
        //     }
        // },
    
        plotOptions: {
            column: {
                stacking: 'normal'
            }
        },
    
        series: [{
            name: 'Total',
            data: [10,40,50,89,67,30,60],
            stack: 'male',
            color: '#a3cced'
        }, {
            name: 'Occupied',
            data: [8,34,45,70,60,20,30],
            stack: 'male',
            color: 'rgb(121, 159, 202)'
        }]
        }
    return(
        <>
            <div className='dashbordContainer'>
            
                <select className='facilitySelect shadow'>
                        <option selected>Filter By Selecting Facilities</option>
                        <option>Facility 1 </option>
                        <option>Facility 2 </option>
                        <option>Facility 3 </option>
                        <option>Facility 4 </option>
                </select>
            
            <div className="facilityContainer">
              <div className='facilityTile shadow' onClick = {props.onBedClick}>
                <div className="totalbeds">
                  <div className='tileLabel'>Total COVID Beds</div>
                  <div className='Count'>251370 
                  <sub className='subTexttextColor'>Available</sub>
                  <div style={ImgStyle}>
                          <img style ={{height:'100%',width:'100%'}} src = {bedImg} alt='bedIcon'></img>
                      </div>
                  </div>
                </div>
                <div className='progressBarParent'>
                  <div className='progressCounts'>
                    <div className='LeftCount textColor'> 500 </div>
                    <div className='RightCount textColor'> 2000 </div>

                  </div>
                  <ProgressBar percent1 ={110} percent2 ={125} percentOf = {200} bgColor = {'#0778f8'}></ProgressBar>
                  <ProgressBar percent1 ={110} percent2 ={125} percentOf = {200} bgColor = {'rgb(212, 31, 31)'}></ProgressBar>
                  <ProgressBar percent1 ={110} percent2 ={125} percentOf = {200} bgColor = {'rgb(212, 31, 31)'}></ProgressBar>
                  <ProgressBar percent1 ={110} percent2 ={125} percentOf = {200} bgColor = {'rgb(212, 31, 31)'}></ProgressBar>
                </div>
              </div>
            </div>
            <div className='facilityTile shadow' onClick = {props.onPatientClick}>
              <div className="totalbeds">
                <div className='tileLabel'>Total Ventilators</div>
                <div className='Count'>251370 <sub className='subTexttextColor'>Available</sub></div>
              </div>
              <div className='progressBarParent'>
                <div className='progressCounts'>
                  <div className='LeftCount textColor'> 500 </div>
                  <div className='RightCount textColor'> 2000 </div>
                </div>
                <ProgressBar percent1 ={500} percent2 ={500+125} percentOf = {2000} bgColor = {'#0778f8'}></ProgressBar>

              </div>

            </div>
           

            <div className='facilityTile shadow ratio'>
              <div className="totalbeds">
                <div className='tileLabel'>Doctors to patient Ratio</div>
                <div className='Count'>2:1 <sub className='subTexttextColor'>Poor</sub></div>
              </div>
            </div>
            <div className='facilityTile shadow ratio' style={{ "marginLeft": "4%" }}>
              <div className="totalbeds">
                <div className='tileLabel'>Nurse to patient Ratio</div>
                <div className='Count'>1:2 <sub className='subTexttextColor'>Average</sub></div>
              </div>
            </div>
            <div className='facilityTile shadow'>
              <HighchartsReact
                highcharts={Highcharts}
                options={options}

              />
            </div>
          </div>
        </>
    )
}
export default FacilityDashbord;