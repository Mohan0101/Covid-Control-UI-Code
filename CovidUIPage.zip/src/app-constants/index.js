export const covidFacilityTypes = [
  {
    key: 'CCC',
    label: 'CCC'
  },
  {
    key: 'DCHC',
    label: 'DCHC'
  },
  {
    key: 'DCH',
    label: 'DCH'
  },
  {
    key: 'Unassigned',
    label: 'Unassigned'
  }
];

export default {
  covidFacilityTypes
};
